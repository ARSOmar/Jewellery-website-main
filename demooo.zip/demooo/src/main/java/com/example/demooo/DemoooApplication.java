package com.example.demooo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoooApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoooApplication.class, args);
	}

}
