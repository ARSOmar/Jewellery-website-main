package com.example.demooo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoooApplicationTests {

	@Test
	void contextLoads() {
	}

}
